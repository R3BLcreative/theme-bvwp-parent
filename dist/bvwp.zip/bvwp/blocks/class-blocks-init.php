<?php

class Blocks_Init {
	public $config;

	public function load_global_config() {
		$this->config = [
			'section_css' => 'infinite-section group/section'
		];
	}
}
