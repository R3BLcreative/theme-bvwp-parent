<?php
get_header();

get_template_part('partials/course', 'hero');

get_template_part('partials/course', 'about');

get_template_part('partials/course', 'info');

get_template_part('partials/course', 'legal');

get_footer();
